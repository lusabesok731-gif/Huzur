package com.huzur.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val KF = listOf(
    0f to (Color(0xFF020C09) to Color(0xFF06211A)),
    4.5f to (Color(0xFF06211A) to Color(0xFF145A47)),
    6f to (Color(0xFF1D6B56) to Color(0xFFF2B36B)),
    7.5f to (Color(0xFF1B7F7A) to Color(0xFF8EE0C8)),
    16.5f to (Color(0xFF1A7C72) to Color(0xFF86D9C3)),
    18f to (Color(0xFF1F5E55) to Color(0xFFF0A860)),
    19.5f to (Color(0xFF123F36) to Color(0xFFD9774F)),
    21f to (Color(0xFF071F1A) to Color(0xFF0E3A30)),
    24f to (Color(0xFF020C09) to Color(0xFF06211A))
)

private fun sky(h: Float): Pair<Color, Color> {
    val i = KF.indexOfLast { it.first <= h }.coerceIn(0, KF.size - 2)
    val a = KF[i]; val b = KF[i + 1]
    val t = ((h - a.first) / (b.first - a.first)).coerceIn(0f, 1f)
    return lerp(a.second.first, b.second.first, t) to lerp(a.second.second, b.second.second, t)
}

private fun frac(a: LocalDateTime, b: LocalDateTime, x: LocalDateTime): Float =
    (Duration.between(a, x).seconds.toFloat() / Duration.between(a, b).seconds.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

fun DrawScope.ring(prog: Float, color: Color, track: Color, sw: Float) {
    val s = Stroke(width = sw, cap = StrokeCap.Round)
    val tl = Offset(sw / 2, sw / 2); val sz = Size(size.width - sw, size.height - sw)
    drawArc(track, 0f, 360f, false, topLeft = tl, size = sz, style = s)
    drawArc(color, -90f, 360f * prog, false, topLeft = tl, size = sz, style = s)
}

private val DAY_FMT = DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale("tr"))

@Composable
fun HomeScreen(st: Store) {
    val p = LocalPal.current
    val c = st.ctx
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val d = now.toLocalDate()
    val ver = st.ver
    val yest = remember(d, ver) { PrayerSource.day(c, d.minusDays(1)) }
    val tod = remember(d, ver) { PrayerSource.day(c, d) }
    val tom = remember(d, ver) { PrayerSource.day(c, d.plusDays(1)) }
    val all = yest + tod + tom
    val ni = all.indexOfFirst { it.isAfter(now) }.coerceAtLeast(1)
    val next = all[ni]; val prev = all[ni - 1]
    val nextIdx = ni % 6
    val prog = frac(prev, next, now)
    val left = Duration.between(now, next).seconds.coerceAtLeast(0)
    val countdown = "%02d:%02d:%02d".format(left / 3600, (left % 3600) / 60, left % 60)
    val official = remember(d, ver) { PrayerSource.official(c, d) }
    val hicri = remember(d, ver) { PrayerSource.hijri(c, d) }
    val ker = remember(d, ver) { PrayerSource.kerahat(c, d) }
    val inKer = ker.firstOrNull { now.isAfter(it.first) && now.isBefore(it.second) }

    val sr = tod[1]; val ss = tod[4]
    val isDay = now.isAfter(sr) && now.isBefore(ss)
    val q: Float = if (isDay) frac(sr, ss, now) else if (now.isAfter(ss)) frac(ss, tom[1], now) else frac(yest[4], sr, now)
    val vh = if (isDay) 6f + 12f * q else (18f + 12f * q) % 24f
    val (top, bot) = sky(vh)
    val starAlpha = if (isDay) (1f - sin(PI.toFloat() * q) * 3f).coerceIn(0f, 1f) else 1f
    val stars = remember { val r = java.util.Random(7); List(60) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat() * 6f) } }
    val tw by rememberInfiniteTransition(label = "tw").animateFloat(0f, 1f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "tw")
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(400.dp).clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width; val h = size.height
                drawRect(Brush.verticalGradient(listOf(top, bot)))
                stars.forEach { (sx, sy, ph) ->
                    val al = starAlpha * (0.35f + 0.65f * abs(sin(ph + tw * 3.14159f)))
                    drawCircle(Color.White.copy(alpha = al), 1.2f + ph % 1.6f, Offset(sx * w, sy * h * 0.62f))
                }
                val bx = w * (0.12f + 0.76f * q)
                val by = h * 0.68f - sin(PI.toFloat() * q) * h * 0.44f
                val cen = Offset(bx, by)
                if (isDay) {
                    drawCircle(Brush.radialGradient(listOf(Color(0x99FFE9A8), Color(0x00FFE9A8)), cen, w * 0.25f), w * 0.25f, cen)
                    drawCircle(Color(0xFFFFD54F), w * 0.06f, cen)
                } else {
                    drawCircle(Brush.radialGradient(listOf(Color(0x66BFFFE4), Color(0x00BFFFE4)), cen, w * 0.22f), w * 0.22f, cen)
                    drawCircle(Color(0xFFF1FFF8), w * 0.055f, cen)
                    drawCircle(Color(0xFFD0E8DC), w * 0.012f, cen + Offset(-w * 0.02f, -w * 0.01f))
                    drawCircle(Color(0xFFD0E8DC), w * 0.008f, cen + Offset(w * 0.02f, w * 0.02f))
                }
                val sil = Color(0xFF03100C).copy(alpha = 0.92f)
                val gy = h * 0.91f
                drawRect(sil, Offset(0f, gy), Size(w, h - gy))
                drawArc(sil, 180f, 180f, true, Offset(w * 0.5f - w * 0.15f, gy - w * 0.15f), Size(w * 0.3f, w * 0.3f))
                drawArc(sil, 180f, 180f, true, Offset(w * 0.28f, gy - w * 0.08f), Size(w * 0.16f, w * 0.16f))
                drawArc(sil, 180f, 180f, true, Offset(w * 0.56f, gy - w * 0.08f), Size(w * 0.16f, w * 0.16f))
                for (mx in listOf(0.18f, 0.80f)) {
                    drawRect(sil, Offset(w * mx, gy - h * 0.30f), Size(w * 0.026f, h * 0.30f))
                    val tip = Path().apply {
                        moveTo(w * mx - w * 0.006f, gy - h * 0.30f); lineTo(w * mx + w * 0.013f, gy - h * 0.36f)
                        lineTo(w * mx + w * 0.032f, gy - h * 0.30f); close()
                    }
                    drawPath(tip, sil)
                }
            }
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        val pl = Notifier.place(c)
                        T("📍 $pl", 14, Color.White, FontWeight.SemiBold)
                        val sub = listOf(st.s("mah", ""), st.s("sok", "")).filter { it.isNotEmpty() }.joinToString(", ")
                        if (sub.isNotEmpty()) T(sub, 11, Color.White.copy(alpha = 0.75f))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        T(d.format(DAY_FMT), 11, Color.White.copy(alpha = 0.85f))
                        if (hicri.isNotEmpty()) T(hicri, 11, Color.White.copy(alpha = 0.7f))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.size(206.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) { ring(prog * appear.value, Color.White, Color.White.copy(alpha = 0.2f), 9.dp.toPx()) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        T("Sıradaki vakit", 12, Color.White.copy(alpha = 0.75f))
                        T(Notifier.names[nextIdx], 26, Color.White, FontWeight.SemiBold)
                        T(countdown, 30, Color.White, FontWeight.Light)
                        T(next.format(HM), 13, Color.White.copy(alpha = 0.75f))
                    }
                }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(50)).background((if (official) p.accent else p.gold).copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    T(if (official) "✓ Diyanet İşleri Başkanlığı vakitleri" else "Hesaplanan vakitler (Diyanet verisi yok)", 11, if (official) p.accent else p.gold, FontWeight.Medium)
                }
            }
            if (inKer != null) {
                Panel(border = p.gold, hi = true) {
                    T("⚠️ Şu an kerahat vakti", 15, p.gold, FontWeight.SemiBold)
                    T("Yaklaşık ${inKer.second.format(HM)}'e kadar nafile namaz kılınmaz.", 12, p.sub)
                }
            }
            val emo = listOf("🌌", "🌅", "☀️", "🌤️", "🌇", "🌙")
            tod.forEachIndexed { i, t ->
                val a = (appear.value * 7f - i * 0.6f).coerceIn(0f, 1f)
                Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 50f }) {
                    PrayerRow(Notifier.names[i], emo[i], t, if (i == nextIdx) 1 else if (t.isBefore(now)) 0 else 2)
                }
            }
            val pool = remember { DUAS.filter { it.ar.length < 160 && (it.isHadis || it.isQuran) } }
            val z = pool[d.dayOfYear % pool.size]
            val ar = st.i("arsz", 26)
            Spacer(Modifier.height(4.dp))
            SectionTitle("✨", "Günün zikri")
            Panel(Modifier.pressable { st.readDua(z.title) }, hi = true) {
                T(z.title, 15, p.text, FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                androidx.compose.material3.Text(z.ar, color = p.text, fontSize = ar.sp, lineHeight = (ar * 1.7f).sp, textAlign = TextAlign.Right, fontFamily = Arab, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                T(z.ok, 12, p.accent, italic = true, lh = 17)
                T(z.tr, 12, p.sub, lh = 17)
                Spacer(Modifier.height(6.dp))
                T("Dokun: okudum ✓ (${st.i("r_" + z.title, 0)})", 11, p.sub)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun PrayerRow(name: String, emoji: String, time: LocalDateTime, state: Int) {
    val p = LocalPal.current
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (state == 1) p.accent.copy(alpha = 0.16f) else p.card)
            .border(1.dp, if (state == 1) p.accent.copy(alpha = pulse) else p.line, shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        T(name, 16, if (state == 0) p.sub else p.text, FontWeight.Medium, Modifier.weight(1f))
        if (state == 1) { Box(Modifier.size(8.dp).clip(CircleShape).background(p.accent.copy(alpha = pulse))); Spacer(Modifier.width(10.dp)) }
        T(time.format(HM), 20, if (state == 1) p.accent else if (state == 0) p.sub else p.text, FontWeight.SemiBold)
    }
}
