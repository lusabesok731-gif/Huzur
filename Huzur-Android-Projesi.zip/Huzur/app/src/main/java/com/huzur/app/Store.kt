package com.huzur.app

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

data class Preset(val key: String, val name: String, val ar: String, val ok: String, val tr: String, val target: Int)

val PRESETS = listOf(
    Preset("sub", "Sübhânallâh", "سُبْحَانَ اللَّهِ", "Sübhânallâh", "Allah her türlü eksiklikten uzaktır", 33),
    Preset("hamd", "Elhamdülillâh", "الْحَمْدُ لِلَّهِ", "Elhamdülillâh", "Hamd Allah'a mahsustur", 33),
    Preset("ekber", "Allâhü Ekber", "اللَّهُ أَكْبَرُ", "Allâhü ekber", "Allah en büyüktür", 33),
    Preset("tevhid", "Lâ ilâhe illallah", "لَا إِلَهَ إِلَّا اللَّهُ", "Lâ ilâhe illallâh", "Allah'tan başka ilah yoktur", 100),
    Preset("salavat", "Salavât", "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ", "Allâhümme salli alâ Muhammed", "Allah'ım! Muhammed'e salât eyle", 100),
    Preset("istigfar", "İstiğfâr", "أَسْتَغْفِرُ اللَّهَ", "Estağfirullâh", "Allah'tan bağışlanma dilerim", 100),
    Preset("hasbi", "Hasbünallâh", "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ", "Hasbünallâhü ve ni'mel vekîl", "Allah bize yeter, O ne güzel vekildir", 100)
)
val FATIMA = listOf("sub" to 33, "hamd" to 33, "ekber" to 34)

private val RESCHED = listOf("pn_", "ker", "kdur", "zk", "persist", "off_", "ilceId", "lat", "lon", "hanafi")

class Store(val ctx: Context) {
    val m = mutableStateMapOf<String, String>()
    var tabRequest by mutableStateOf(-1)
    var ver by mutableStateOf(0)
    var locStatus by mutableStateOf("")
    var locBusy by mutableStateOf(false)

    init { reload() }

    fun reload() { Cfg.sp(ctx).all.forEach { (k, v) -> m[k] = v.toString() }; ver++ }

    fun s(k: String, d: String): String = m[k] ?: d
    fun b(k: String, d: Boolean): Boolean = m[k]?.toBooleanStrictOrNull() ?: d
    fun i(k: String, d: Int): Int = m[k]?.toIntOrNull() ?: d

    fun put(k: String, v: Any) {
        m[k] = v.toString(); Cfg.put(ctx, k, v)
        if (k == "pre" || k == "notif" || RESCHED.any { k.startsWith(it) }) { ver++; Scheduler.rescheduleAll(ctx) }
    }

    suspend fun locate() {
        locBusy = true
        Loc.locate(ctx) { locStatus = it }
        locBusy = false
        reload()
    }

    suspend fun refreshTimes() {
        locStatus = "Vakitler yenileniyor…"
        val ok = Loc.refresh(ctx)
        Scheduler.rescheduleAll(ctx)
        reload()
        locStatus = if (ok) "Diyanet vakitleri güncellendi ✓" else "Güncellenemedi. İnternet bağlantını kontrol et."
    }

    fun chooseDistrict(il: String, id: String, ilce: String) { Loc.choose(ctx, il, id, ilce); reload(); Scheduler.rescheduleAll(ctx) }

    // ── ses / titreşim ──
    private val pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val sTick = pool.load(ctx, R.raw.tick, 1)
    private val sDone = pool.load(ctx, R.raw.done, 1)
    @Suppress("DEPRECATION")
    private val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    fun buzz(ms: Long) {
        if (b("haptic", true)) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    // ── sayaç / okuma ──
    fun todayCount(): Int = i(Cfg.dayKey(), 0)
    fun week(): Int = (0..6).sumOf { i(Cfg.dayKey(LocalDate.now().minusDays(it.toLong())), 0) }

    private fun bumpToday() = put(Cfg.dayKey(), todayCount() + 1)

    fun readDua(title: String) {
        put("r_$title", i("r_$title", 0) + 1)
        bumpToday()
        if (b("sound", true)) pool.play(sTick, 1f, 1f, 1, 0, 1f)
        buzz(25)
    }

    fun pick(p: Preset) { put("preset", p.key); put("guided", false); put("step", 0); put("target", p.target); put("count", 0); put("label", "") }

    fun sendToTasbih(d: Dua) {
        put("preset", "custom"); put("guided", false); put("label", d.title)
        put("c_ar", d.ar); put("c_ok", d.ok); put("c_tr", d.tr)
        put("target", d.rep.coerceAtLeast(1)); put("count", 0)
    }

    fun setGuided(on: Boolean) {
        put("guided", on); put("count", 0); put("step", 0)
        if (on) { put("preset", FATIMA[0].first); put("target", FATIMA[0].second); put("label", "") }
    }

    /** true → tur/hedef tamamlandı */
    fun tap(): Boolean {
        val target = i("target", 33)
        val c = i("count", 0) + 1
        bumpToday()
        if (c >= target) {
            if (b("sound", true)) pool.play(sDone, 1f, 1f, 1, 0, 1f)
            buzz(180)
            put("count", 0)
            if (b("guided", false) && i("step", 0) < 2) {
                val st = i("step", 0) + 1
                put("step", st); put("preset", FATIMA[st].first); put("target", FATIMA[st].second)
            } else {
                put("rounds", i("rounds", 0) + 1)
                if (b("guided", false)) { put("step", 0); put("preset", FATIMA[0].first); put("target", FATIMA[0].second) }
            }
            return true
        }
        put("count", c)
        if (b("sound", true)) pool.play(sTick, 1f, 1f, 1, 0, 1f)
        buzz(14)
        return false
    }

    fun undo() { val c = i("count", 0); if (c > 0) { put("count", c - 1); put(Cfg.dayKey(), (todayCount() - 1).coerceAtLeast(0)) } }
    fun reset() { put("count", 0); put("rounds", 0); if (b("guided", false)) setGuided(true) }
}
