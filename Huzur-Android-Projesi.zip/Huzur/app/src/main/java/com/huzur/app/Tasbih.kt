package com.huzur.app

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TasbihScreen(st: Store) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val count = st.i("count", 0)
    val target = st.i("target", 33).coerceAtLeast(1)
    val key = st.s("preset", "sub")
    val guided = st.b("guided", false)
    val step = st.i("step", 0)
    val pr = PRESETS.firstOrNull { it.key == key }
    val ar = if (key == "custom") st.s("c_ar", "") else pr?.ar ?: ""
    val ok = if (key == "custom") st.s("c_ok", "") else pr?.ok ?: ""
    val tr = if (key == "custom") st.s("c_tr", "") else pr?.tr ?: ""
    val title = if (key == "custom") st.s("label", "Zikir") else pr?.name ?: ""
    val arsz = st.i("arsz", 26)

    val sc = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    val pulse by rememberInfiniteTransition(label = "pl").animateFloat(0.4f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pl")
    val glow by rememberInfiniteTransition(label = "gl").animateFloat(0.85f, 1.0f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "gl")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T("Tesbihat", 26, p.text, FontWeight.SemiBold)
                T("Dokun, say, huzur bul", 12, p.sub)
            }
            Chip(if (guided) "Fâtıma ✓" else "Tesbihat-ı Fâtıma", guided) { st.setGuided(!guided) }
        }
        Spacer(Modifier.height(12.dp))
        LazyRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(PRESETS) { pz -> Chip(pz.name, key == pz.key && !guided) { st.pick(pz) } }
        }
        Spacer(Modifier.height(12.dp))
        Panel(hi = true) {
            if (guided) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    FATIMA.forEachIndexed { i, f ->
                        val on = i <= step
                        Box(Modifier.padding(horizontal = 4.dp).height(5.dp).width(if (i == step) 36.dp else 18.dp).clip(RoundedCornerShape(3.dp)).background(if (on) p.accent else p.line))
                    }
                }
                Spacer(Modifier.height(8.dp))
                T("Adım ${step + 1}/3 • ${FATIMA[step].second} kez", 11, p.sub, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
            }
            Text(ar, color = p.text, fontSize = (arsz + 8).sp, lineHeight = ((arsz + 8) * 1.6f).sp, textAlign = TextAlign.Center, fontFamily = Arab, modifier = Modifier.fillMaxWidth())
            if (st.b("showok", true) && ok.isNotEmpty()) T(ok, 13, p.accent, FontWeight.Medium, Modifier.fillMaxWidth(), TextAlign.Center, italic = true)
            if (st.b("showtr", true) && tr.isNotEmpty()) T(tr, 12, p.sub, modifier = Modifier.fillMaxWidth().padding(top = 2.dp), align = TextAlign.Center)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.size(318.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val beads = 33
                val r = size.minDimension / 2 - 18.dp.toPx()
                val cen = center
                val lit = (count.toFloat() / target * beads).toInt()
                drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = 0.22f * glow), Color.Transparent), cen, size.minDimension * 0.46f), size.minDimension * 0.46f, cen)
                for (i in 0 until beads) {
                    val a = (-PI / 2 + i * 2 * PI / beads).toFloat()
                    val pos = Offset(cen.x + r * cos(a), cen.y + r * sin(a))
                    val on = i < lit; val cur = i == lit
                    if (cur) drawCircle(p.accent.copy(alpha = 0.35f * pulse), 14.dp.toPx(), pos)
                    drawCircle(if (on) p.accent else p.line, if (cur) 7.dp.toPx() else 5.dp.toPx(), pos)
                }
                if (burst.value > 0f && burst.value < 1f) {
                    for (k in 0 until 16) {
                        val a = (k * 2 * PI / 16).toFloat()
                        val dist = size.minDimension * (0.30f + 0.26f * burst.value)
                        drawCircle(p.gold.copy(alpha = 1f - burst.value), 5.dp.toPx() * (1f - burst.value), Offset(cen.x + dist * cos(a), cen.y + dist * sin(a)))
                    }
                }
            }
            Box(
                Modifier.size(206.dp).scale(sc.value).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(p.cardHi, p.card)))
                    .border(1.5.dp, p.accent.copy(alpha = 0.55f), CircleShape)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        scope.launch { sc.animateTo(0.93f, tween(70)); sc.animateTo(1f, spring(0.35f, 300f)) }
                        if (st.tap()) scope.launch { burst.snapTo(0f); burst.animateTo(1f, tween(800)) }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AnimatedContent(
                        count,
                        transitionSpec = { (slideInVertically(tween(160)) { -it / 3 } + fadeIn(tween(120))) togetherWith (slideOutVertically(tween(160)) { it / 3 } + fadeOut(tween(100))) },
                        label = "cnt"
                    ) { n -> T("$n", 70, p.text, FontWeight.Light) }
                    T("/ $target", 15, p.sub)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(33, 99, 100, 500, 1000)) { n -> Chip("$n", target == n && !guided) { if (!guided) { st.put("target", n); st.put("count", 0) } } }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Tur" to st.i("rounds", 0), "Bugün" to st.todayCount(), "Hafta" to st.week()).forEach { (l, v) ->
                Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(p.card).border(1.dp, p.line, RoundedCornerShape(20.dp)).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    T("$v", 22, p.gold, FontWeight.SemiBold); T(l, 11, p.sub)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PButton("↶ Geri al", Modifier.weight(1f), filled = false) { st.undo() }
            PButton("↺ Sıfırla", Modifier.weight(1f), filled = false) { st.reset() }
        }
        Spacer(Modifier.height(10.dp))
    }
}
