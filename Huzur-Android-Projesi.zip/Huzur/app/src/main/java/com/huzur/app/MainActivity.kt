package com.huzur.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch
import java.time.LocalDateTime

fun batteryExempt(c: Context): Boolean =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

/** Pil optimizasyonu kısıtlamasını kaldırma ekranına yönlendirir (sistem izin penceresi) */
fun openBattery(c: Context) {
    try {
        c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)))
    } catch (e: Exception) {
        try { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        catch (e2: Exception) { c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))) }
    }
}

fun openAppDetails(c: Context) {
    c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)))
}

fun alarmOk(c: Context): Boolean =
    Build.VERSION.SDK_INT < 31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

fun autoCat(): String = when (LocalDateTime.now().hour) { in 4..13 -> "Sabah"; in 14..20 -> "Akşam"; else -> "Uyku" }

class MainActivity : ComponentActivity() {
    private lateinit var st: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = Store(applicationContext)
        handle(intent)
        Scheduler.rescheduleAll(this)
        setContent {
            val mode = st.s("theme", "auto")
            val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            val pal = makePal(dark, st.s("accent", "zumrut"))
            val act = this@MainActivity
            SideEffect {
                val t = android.graphics.Color.TRANSPARENT
                act.enableEdgeToEdge(
                    if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t),
                    if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
                )
            }
            CompositionLocalProvider(LocalPal provides pal) {
                MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = pal.accent) else lightColorScheme(primary = pal.accent)) { App(st) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handle(intent) }
    override fun onResume() { super.onResume(); if (::st.isInitialized) st.reload() }

    private fun handle(i: Intent?) {
        val t = i?.getStringExtra("read") ?: return
        st.readDua(t); st.tabRequest = 2
        val nid = i.getIntExtra("nid", 0)
        if (nid > 0) (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(nid)
    }
}

@Composable
fun App(st: Store) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var cat by rememberSaveable { mutableStateOf(autoCat()) }
    var gate by remember { mutableStateOf(!st.b("onboarded", false) || !batteryExempt(ctx)) }
    LaunchedEffect(st.tabRequest) { if (st.tabRequest >= 0) { tab = st.tabRequest; st.tabRequest = -1; gate = false } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg, p.bg2)))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = if (p.dark) 0.16f else 0.12f), Color.Transparent), Offset(size.width * 0.9f, size.height * 0.1f), size.width * 0.8f), size.width * 0.8f, Offset(size.width * 0.9f, size.height * 0.1f))
            drawCircle(Brush.radialGradient(listOf(p.gold.copy(alpha = if (p.dark) 0.07f else 0.06f), Color.Transparent), Offset(size.width * 0.05f, size.height * 0.85f), size.width * 0.7f), size.width * 0.7f, Offset(size.width * 0.05f, size.height * 0.85f))
        }
        if (gate) {
            Onboarding(st) { gate = false }
        } else {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        tab,
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(tween(320)) { it / 8 * dir } + fadeIn(tween(300))) togetherWith
                                (slideOutHorizontally(tween(220)) { -it / 8 * dir } + fadeOut(tween(160)))
                        },
                        label = "tabs"
                    ) { t ->
                        when (t) {
                            0 -> HomeScreen(st)
                            1 -> TasbihScreen(st)
                            2 -> DuaScreen(st, cat, { cat = it }) { tab = 1 }
                            3 -> QiblaScreen(st)
                            else -> SettingsScreen(st)
                        }
                    }
                }
                NavBar(tab) { tab = it }
            }
        }
    }
}

@Composable
fun NavBar(sel: Int, on: (Int) -> Unit) {
    val p = LocalPal.current
    val items = listOf("🕌" to "Vakitler", "📿" to "Tesbihat", "📖" to "Dualar", "🧭" to "Kıble", "⚙️" to "Ayarlar")
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).clip(shape)
            .background(if (p.dark) Color(0xCC0A1F18) else Color(0xF2FFFFFF)).border(1.dp, p.line, shape).padding(6.dp)
    ) {
        items.forEachIndexed { i, (e, l) ->
            val a by animateFloatAsState(if (sel == i) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 400f), label = "nav")
            Column(
                Modifier.weight(1f).pressable { on(i) }.clip(RoundedCornerShape(22.dp)).background(p.accent.copy(alpha = 0.18f * a)).padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(e, fontSize = (19 + 5 * a).sp)
                T(l, 10, if (sel == i) p.accent else p.sub, if (sel == i) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

// ───────────── Karşılama + izinler + pil kısıtlaması ─────────────
@Composable
fun StepCard(emoji: String, title: String, desc: String, done: Boolean, critical: Boolean, button: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Panel(border = if (critical && !done) p.gold else null, hi = critical && !done) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(if (done) p.accent.copy(alpha = 0.2f) else p.gold.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Text(if (done) "✓" else emoji, fontSize = 20.sp, color = if (done) p.accent else p.text)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T(title, 15, p.text, FontWeight.SemiBold)
                T(desc, 12, p.sub, lh = 17)
            }
        }
        if (!done) { Spacer(Modifier.height(12.dp)); PButton(button, Modifier.fillMaxWidth(), onClick = onClick) }
    }
}

@Composable
fun Onboarding(st: Store, onDone: () -> Unit) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val locOk = remember(tick, st.locStatus) { hasLocationPermission(ctx) && st.s("ilceId", "").isNotEmpty() }
    val notifOk = remember(tick) { Notifier.canPost(ctx) }
    val alarm = remember(tick) { alarmOk(ctx) }
    val bat = remember(tick) { batteryExempt(ctx) }
    val locL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { scope.launch { st.locate() } }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val pulse by rememberInfiniteTransition(label = "ob").animateFloat(0.85f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "ob")

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(10.dp))
        Box(Modifier.size(72.dp).scale(pulse).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(p.accent, p.accent.copy(alpha = 0.5f)))), contentAlignment = Alignment.Center) { Text("☪", fontSize = 36.sp, color = p.onAccent) }
        T("Huzur'a hoş geldin", 28, p.text, FontWeight.SemiBold)
        T("Ezan vakitlerinin tam zamanında gelmesi için birkaç izne ihtiyacımız var.", 14, p.sub, lh = 21)

        StepCard("🔋", "Pil kısıtlamasını kaldır", "Çok önemli: Telefon pil tasarrufu uygulamayı uyutursa ezan bildirimi gelmez. Açılan pencerede “İzin ver”e dokun. Samsung: Ayarlar › Uygulamalar › Huzur › Pil › Sınırsız.", bat, true, "Pil kısıtlamasını kaldır") { openBattery(ctx) }
        if (!bat) PButton("Uygulama pil ayarlarını aç", Modifier.fillMaxWidth(), filled = false) { openAppDetails(ctx) }
        StepCard("📍", "Konum", "Mahalle ve sokağına kadar konumunu bulur, bulunduğun ilçenin Diyanet vakitlerini indirir.", locOk, true, "İzin ver ve konumu bul") {
            locL.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        if (st.locStatus.isNotEmpty()) Panel(pad = 12) { T(st.locStatus, 13, p.accent, FontWeight.Medium); if (st.s("addr", "").isNotEmpty()) T("📍 " + st.s("addr", ""), 12, p.sub) }
        if (Build.VERSION.SDK_INT >= 33) StepCard("🔔", "Bildirimler", "Ezan, kerahat ve zikir hatırlatmaları için gerekli.", notifOk, true, "Bildirimlere izin ver") { notifL.launch(Manifest.permission.POST_NOTIFICATIONS) }
        if (!alarm) StepCard("⏰", "Tam zamanlı alarm", "Bildirimlerin saniyesinde gelmesi için “Alarm ve hatırlatıcılar” iznini aç.", false, true, "Alarm iznini aç") {
            if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
        }
        Spacer(Modifier.height(4.dp))
        PButton(if (bat) "Başla" else "Şimdilik geç", Modifier.fillMaxWidth(), filled = bat) { st.put("onboarded", true); onDone() }
        Spacer(Modifier.height(16.dp))
    }
}
