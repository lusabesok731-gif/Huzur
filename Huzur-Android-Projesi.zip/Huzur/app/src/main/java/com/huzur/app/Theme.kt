package com.huzur.app

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

data class Pal(
    val bg: Color, val bg2: Color, val card: Color, val cardHi: Color, val line: Color,
    val text: Color, val sub: Color, val accent: Color, val onAccent: Color, val gold: Color, val dark: Boolean
)

data class AccentOpt(val key: String, val name: String, val dk: Color, val lt: Color)

val ACCENTS = listOf(
    AccentOpt("zumrut", "Zümrüt", Color(0xFF34D399), Color(0xFF047857)),
    AccentOpt("nane", "Nane", Color(0xFF6EE7B7), Color(0xFF059669)),
    AccentOpt("cam", "Çam", Color(0xFF4ADE80), Color(0xFF15803D)),
    AccentOpt("zeytin", "Zeytin", Color(0xFFA3E635), Color(0xFF4D7C0F)),
    AccentOpt("turkuaz", "Turkuaz", Color(0xFF2DD4BF), Color(0xFF0F766E))
)

fun makePal(dark: Boolean, key: String): Pal {
    val a = ACCENTS.firstOrNull { it.key == key } ?: ACCENTS[0]
    return if (dark) Pal(
        Color(0xFF04110D), Color(0xFF0A1F18), Color(0x14FFFFFF), Color(0x26FFFFFF), Color(0x1FFFFFFF),
        Color(0xFFECFDF5), Color(0xFF8FB5A5), a.dk, Color(0xFF03170F), Color(0xFFE9C46A), true
    ) else Pal(
        Color(0xFFF1F7F3), Color(0xFFE2EEE7), Color(0xE6FFFFFF), Color(0xFFFFFFFF), Color(0x1A064E3B),
        Color(0xFF052E22), Color(0xFF5B7A6B), a.lt, Color.White, Color(0xFFB7791F), false
    )
}

val LocalPal = staticCompositionLocalOf { makePal(true, "zumrut") }

val Sans = FontFamily(
    Font(R.font.poppins_light, FontWeight.Light),
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_semibold, FontWeight.SemiBold),
    Font(R.font.poppins_semibold, FontWeight.Bold)
)
val Arab = FontFamily(Font(R.font.amiri_regular))

@Composable
fun T(
    s: String, size: Int = 15, color: Color = LocalPal.current.text, w: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier, align: TextAlign? = null, lh: Int = 0, italic: Boolean = false, family: FontFamily = Sans
) = Text(
    s, modifier = modifier, color = color, fontSize = size.sp, fontWeight = w, textAlign = align, fontFamily = family,
    fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
    lineHeight = if (lh > 0) lh.sp else TextUnit.Unspecified
)

fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pr) 0.95f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "press")
    this.scale(sc).clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun Panel(modifier: Modifier = Modifier, hi: Boolean = false, border: Color? = null, pad: Int = 16, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(if (hi) p.cardHi else p.card)
            .border(1.dp, border ?: p.line, shape).padding(pad.dp),
        content = content
    )
}

@Composable
fun Chip(label: String, sel: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val bg by animateColorAsState(if (sel) p.accent else p.card, tween(220), label = "chip")
    Box(
        modifier.pressable(onClick).clip(RoundedCornerShape(50)).background(bg)
            .border(1.dp, if (sel) Color.Transparent else p.line, RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { T(label, 13, if (sel) p.onAccent else p.text, FontWeight.Medium) }
}

@Composable
fun PButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.pressable(onClick).clip(shape)
            .background(if (filled) Brush.horizontalGradient(listOf(p.accent, p.accent.copy(alpha = 0.78f))) else Brush.horizontalGradient(listOf(p.card, p.card)))
            .border(1.dp, if (filled) Color.Transparent else p.line, shape)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14, if (filled) p.onAccent else p.text, FontWeight.SemiBold, align = TextAlign.Center) }
}

@Composable
fun SectionTitle(emoji: String, title: String) {
    val p = LocalPal.current
    Row(Modifier.padding(start = 4.dp, top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(p.accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 15.sp) }
        Spacer(Modifier.width(10.dp))
        T(title, 15, p.text, FontWeight.SemiBold)
    }
}

@Composable
fun SwitchRow(title: String, sub: String, v: Boolean, on: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            T(title, 14, p.text, FontWeight.Medium)
            if (sub.isNotEmpty()) T(sub, 11, p.sub, lh = 15)
        }
        Switch(v, on, colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = p.onAccent, uncheckedTrackColor = p.line, uncheckedThumbColor = p.sub, uncheckedBorderColor = Color.Transparent))
    }
}

@Composable
fun RoundBtn(label: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.size(36.dp).pressable(onClick).clip(CircleShape).background(p.accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { T(label, 18, p.accent, FontWeight.SemiBold) }
}

@Composable
fun Stepper(title: String, value: Int, unit: String, min: Int, max: Int, step: Int = 1, onChange: (Int) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        T(title, 14, p.text, FontWeight.Medium, Modifier.weight(1f))
        RoundBtn("−") { onChange((value - step).coerceAtLeast(min)) }
        T("$value $unit", 14, p.text, FontWeight.SemiBold, Modifier.widthIn(min = 70.dp), TextAlign.Center)
        RoundBtn("+") { onChange((value + step).coerceAtMost(max)) }
    }
}
