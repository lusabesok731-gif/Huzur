package com.huzur.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

fun pretty(s: String): String = s.lowercase(Locale("tr")).split(" ")
    .joinToString(" ") { w -> w.replaceFirstChar { it.titlecase(Locale("tr")) } }

fun hasLocationPermission(c: Context): Boolean =
    c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

/** Konum → mahalle/sokak (OpenStreetMap) → Diyanet ilçesi → Diyanet aylık vakitleri */
object Loc {
    const val BASE = "https://ezanvakti.emushaf.net"

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "HuzurApp/1.0 (Android namaz vakti uygulamasi)")
        c.setRequestProperty("Accept-Language", "tr")
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun norm(s: String): String {
        var x = s.trim().lowercase(Locale("tr"))
        x = x.replace("ı", "i").replace("ğ", "g").replace("ü", "u").replace("ş", "s")
            .replace("ö", "o").replace("ç", "c").replace("â", "a").replace("î", "i").replace("û", "u")
        x = x.replace(Regex("\\b(ili|il|ilcesi|belediyesi|province|merkez)\\b"), " ")
        return x.replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    data class Place(val line: String, val mahalle: String, val sokak: String, val ilce: String, val il: String, val cands: List<String>)

    suspend fun cities(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val a = JSONArray(http("$BASE/sehirler/2"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("SehirID") to o.getString("SehirAdi") } }
    }

    suspend fun districts(sehirId: String): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val a = JSONArray(http("$BASE/ilceler/$sehirId"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("IlceID") to o.getString("IlceAdi") } }
    }

    suspend fun reverse(lat: Double, lon: Double): Place? = withContext(Dispatchers.IO) {
        try {
            val o = JSONObject(http("https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=18&accept-language=tr&lat=$lat&lon=$lon"))
            val a = o.optJSONObject("address") ?: return@withContext null
            fun g(vararg k: String): String { for (x in k) { val v = a.optString(x, ""); if (v.isNotEmpty()) return v }; return "" }
            val mah = g("neighbourhood", "suburb", "quarter", "residential")
            val road = g("road", "pedestrian", "footway")
            val il = g("state", "province")
            val cands = listOf("county", "city_district", "town", "city", "municipality", "district", "village", "suburb")
                .map { a.optString(it, "") }.filter { it.isNotEmpty() }
            val ilce = cands.firstOrNull() ?: ""
            val parts = listOf(mah, road, ilce, il).filter { it.isNotEmpty() }.distinct()
            Place(parts.joinToString(", "), mah, road, ilce, il, cands)
        } catch (e: Exception) { null }
    }

    suspend fun resolve(ctx: Context, p: Place): Boolean = try {
        val cs = cities(); val n = norm(p.il)
        val sehir = cs.firstOrNull { norm(it.second) == n }
            ?: cs.firstOrNull { n.isNotEmpty() && (norm(it.second).contains(n) || n.contains(norm(it.second))) }
        if (sehir == null) false else {
            val ds = districts(sehir.first)
            var ilce: Pair<String, String>? = null
            for (c in p.cands) { val cn = norm(c); ilce = ds.firstOrNull { norm(it.second) == cn }; if (ilce != null) break }
            if (ilce == null) for (c in p.cands) {
                val cn = norm(c); if (cn.isEmpty()) continue
                ilce = ds.firstOrNull { norm(it.second).contains(cn) || cn.contains(norm(it.second)) }; if (ilce != null) break
            }
            if (ilce == null) ilce = ds.firstOrNull { norm(it.second) == norm(sehir.second) } ?: ds.first()
            choose(ctx, sehir.second, ilce.first, ilce.second)
            true
        }
    } catch (e: Exception) { false }

    fun choose(ctx: Context, ilName: String, ilceId: String, ilceName: String) {
        Cfg.put(ctx, "ilceId", ilceId); Cfg.put(ctx, "dy_ilce", pretty(ilceName)); Cfg.put(ctx, "dy_il", pretty(ilName))
    }

    suspend fun refresh(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val id = Cfg.s(ctx, "ilceId", "")
        if (id.isEmpty()) return@withContext false
        try {
            val raw = http("$BASE/vakitler/$id")
            if (JSONArray(raw).length() < 5) return@withContext false
            Cfg.put(ctx, "vk_json", raw); Cfg.put(ctx, "vk_ilce", id); Cfg.put(ctx, "vk_time", System.currentTimeMillis())
            true
        } catch (e: Exception) { false }
    }

    @SuppressLint("MissingPermission")
    private suspend fun one(ctx: Context, provider: String): Location? = suspendCancellableCoroutine { cont: CancellableContinuation<Location?> ->
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            if (!lm.isProviderEnabled(provider)) { cont.resume(null); return@suspendCancellableCoroutine }
            if (Build.VERSION.SDK_INT >= 30) {
                val cs = CancellationSignal()
                cont.invokeOnCancellation { cs.cancel() }
                lm.getCurrentLocation(provider, cs, ctx.mainExecutor) { l -> if (cont.isActive) cont.resume(l) }
            } else {
                val ls = object : LocationListener {
                    override fun onLocationChanged(l: Location) { if (cont.isActive) cont.resume(l) }
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                }
                cont.invokeOnCancellation { lm.removeUpdates(ls) }
                lm.requestSingleUpdate(provider, ls, Looper.getMainLooper())
            }
        } catch (e: Exception) { if (cont.isActive) cont.resume(null) }
    }

    @SuppressLint("MissingPermission")
    suspend fun fix(ctx: Context): Location? {
        if (!hasLocationPermission(ctx)) return null
        val fine = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        var l: Location? = null
        if (fine) l = withTimeoutOrNull(12000) { one(ctx, LocationManager.GPS_PROVIDER) }
        if (l == null) l = withTimeoutOrNull(8000) { one(ctx, LocationManager.NETWORK_PROVIDER) }
        if (l == null) {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            l = lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
        }
        return l
    }

    suspend fun locate(ctx: Context, say: (String) -> Unit): Boolean {
        say("Konum alınıyor…")
        val l = fix(ctx)
        if (l == null) { say("Konum alınamadı. Konum servisini açıp tekrar dene."); return false }
        Cfg.put(ctx, "lat", l.latitude); Cfg.put(ctx, "lon", l.longitude)
        say("Mahalle ve sokak bulunuyor…")
        val p = reverse(l.latitude, l.longitude)
        if (p != null) {
            Cfg.put(ctx, "addr", p.line); Cfg.put(ctx, "mah", p.mahalle); Cfg.put(ctx, "sok", p.sokak)
            say("Diyanet ilçesi eşleştiriliyor…")
            if (!resolve(ctx, p)) say("Bu konum için Diyanet ilçesi bulunamadı. İl/İlçeyi elle seçebilirsin.")
        } else {
            Cfg.put(ctx, "addr", String.format(Locale.US, "%.5f, %.5f", l.latitude, l.longitude))
        }
        say("Diyanet vakitleri indiriliyor…")
        val ok = refresh(ctx)
        Scheduler.rescheduleAll(ctx)
        say(if (ok) "Hazır ✓ Diyanet vakitleri yüklendi" else "İnternet yok ya da servis yanıt vermedi. Hesaplanan vakitler gösteriliyor.")
        return true
    }
}
