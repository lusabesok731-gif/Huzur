package com.huzur.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch

@Composable
fun DuaScreen(st: Store, cat: String, setCat: (String) -> Unit, goTasbih: () -> Unit) {
    val p = LocalPal.current
    var q by remember { mutableStateOf("") }
    val list = remember(cat, q) {
        val n = Loc.norm(q)
        if (n.isEmpty()) DUAS.filter { cat in it.cats }
        else DUAS.filter { Loc.norm(it.title + " " + it.tr + " " + it.ok).contains(n) }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            T("Dualar & Zikirler", 26, p.text, FontWeight.SemiBold)
            T("Kur'an ve hadis kaynaklı • bir duaya dokunmak onu okumuş sayar", 12, p.sub, modifier = Modifier.padding(top = 2.dp))
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card).border(1.dp, p.line, RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🔎", fontSize = 15.sp)
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    q, { q = it }, singleLine = true, cursorBrush = SolidColor(p.accent),
                    textStyle = TextStyle(color = p.text, fontSize = 14.sp, fontFamily = Sans),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner -> if (q.isEmpty()) T("Dua veya zikir ara…", 14, p.sub); inner() }
                )
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CATS) { c -> Chip("${CAT_EMOJI[c]} $c", c == cat && q.isEmpty()) { q = ""; setCat(c) } }
            }
        }
        items(list, key = { it.title }) { d -> DuaCard(st, d, goTasbih) }
        item { T("Metinleri yaymadan veya öğretmeden önce güvenilir bir meal/hadis kaynağından kontrol etmen önerilir.", 11, p.sub) }
    }
}

@Composable
fun DuaCard(st: Store, d: Dua, goTasbih: () -> Unit) {
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val flash = remember { Animatable(0f) }
    val reads = st.i("r_" + d.title, 0)
    val arsz = st.i("arsz", 26)
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().pressable {
            st.readDua(d.title)
            scope.launch { flash.snapTo(1f); flash.animateTo(0f, tween(900)) }
        }.clip(shape).background(lerp(p.card, p.accent.copy(alpha = 0.22f), flash.value))
            .border(1.dp, lerp(p.line, p.accent, flash.value), shape).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T(d.title, 16, p.text, FontWeight.SemiBold, Modifier.weight(1f))
            if (d.rep > 1) Box(Modifier.clip(RoundedCornerShape(50)).background(p.gold.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 3.dp)) { T("×${d.rep}", 12, p.gold, FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(10.dp))
        Text(d.ar, color = p.text, fontSize = arsz.sp, lineHeight = (arsz * 1.75f).sp, textAlign = TextAlign.Right, fontFamily = Arab, style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.fillMaxWidth())
        if (st.b("showok", true) && d.ok.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            T("Okunuşu", 10, p.accent, FontWeight.SemiBold)
            T(d.ok, 13, p.accent, italic = true, lh = 19)
        }
        if (st.b("showtr", true)) {
            Spacer(Modifier.height(8.dp))
            T("Anlamı", 10, p.sub, FontWeight.SemiBold)
            T(d.tr, 13, p.sub, lh = 19)
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { T("📚 ${d.src}", 11, p.accent, lh = 15) }
            Box(Modifier.clip(RoundedCornerShape(50)).background(if (reads > 0) p.accent.copy(alpha = 0.18f) else p.line).padding(horizontal = 10.dp, vertical = 4.dp)) {
                T(if (reads > 0) "✓ $reads kez okundu" else "Dokun: okudum", 11, if (reads > 0) p.accent else p.sub, FontWeight.Medium)
            }
        }
        Row {
            if (d.rep > 1) Box(Modifier.pressable { st.sendToTasbih(d); goTasbih() }.padding(top = 8.dp, end = 16.dp)) { T("📿 Tesbihata al", 12, p.accent, FontWeight.Medium) }
            Box(Modifier.pressable { clip.setText(AnnotatedString(d.ar + "\n\n" + d.ok + "\n\n" + d.tr + "\n(" + d.src + ")")) }.padding(top = 8.dp)) { T("Kopyala", 12, p.sub, FontWeight.Medium) }
        }
    }
}
