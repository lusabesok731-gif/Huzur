package com.huzur.app

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.*

val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

/** Tüm ayarlar tek yerde (SharedPreferences, string olarak). Receiver'lar da kullanır. */
object Cfg {
    fun sp(c: Context) = c.getSharedPreferences("huzur2", 0)
    fun s(c: Context, k: String, d: String): String = sp(c).getString(k, null) ?: d
    fun b(c: Context, k: String, d: Boolean): Boolean = sp(c).getString(k, null)?.toBooleanStrictOrNull() ?: d
    fun i(c: Context, k: String, d: Int): Int = sp(c).getString(k, null)?.toIntOrNull() ?: d
    fun d(c: Context, k: String, d: Double): Double = sp(c).getString(k, null)?.toDoubleOrNull() ?: d
    fun put(c: Context, k: String, v: Any) { sp(c).edit().putString(k, v.toString()).apply() }
    fun dayKey(d: LocalDate = LocalDate.now()) = "t_$d"
    fun readDua(c: Context, title: String) {
        put(c, "r_$title", i(c, "r_$title", 0) + 1)
        put(c, dayKey(), i(c, dayKey(), 0) + 1)
    }
}

data class Nx(val idx: Int, val next: LocalDateTime, val prev: LocalDateTime)

/** Vakit kaynağı: önce Diyanet verisi (önbellekte), yoksa astronomik hesap. */
object PrayerSource {
    private var key = ""
    private var times = HashMap<String, List<String>>()
    private var hijri = HashMap<String, String>()
    private val df = DateTimeFormatter.ofPattern("dd.MM.yyyy")

    private fun load(c: Context) {
        val raw = Cfg.s(c, "vk_json", "")
        val k = raw.length.toString() + "_" + raw.hashCode() + "_" + Cfg.s(c, "vk_ilce", "") + "_" + Cfg.s(c, "ilceId", "")
        if (k == key) return
        key = k; times = HashMap(); hijri = HashMap()
        if (Cfg.s(c, "vk_ilce", "x") != Cfg.s(c, "ilceId", "")) return
        try {
            val a = JSONArray(raw)
            for (n in 0 until a.length()) {
                val o = a.getJSONObject(n)
                val d = o.getString("MiladiTarihKisa")
                times[d] = listOf(o.getString("Imsak"), o.getString("Gunes"), o.getString("Ogle"), o.getString("Ikindi"), o.getString("Aksam"), o.getString("Yatsi"))
                hijri[d] = o.optString("HicriTarihUzun", "")
            }
        } catch (e: Exception) { times = HashMap() }
    }

    private fun parse(s: String): LocalTime {
        val p = s.trim().split(":")
        return LocalTime.of(p[0].toInt(), p[1].toInt())
    }

    fun official(c: Context, date: LocalDate): Boolean { load(c); return times.containsKey(date.format(df)) }
    fun hijri(c: Context, date: LocalDate): String { load(c); return hijri[date.format(df)] ?: "" }
    fun daysLeft(c: Context): Int {
        load(c); val t = LocalDate.now()
        return times.keys.count { try { !LocalDate.parse(it, df).isBefore(t) } catch (e: Exception) { false } }
    }

    fun day(c: Context, date: LocalDate): List<LocalDateTime> {
        load(c)
        val t = times[date.format(df)]
        val base = if (t != null) t.map { date.atTime(parse(it)) }
        else PrayerCalc.day(date, Cfg.d(c, "lat", 41.0082), Cfg.d(c, "lon", 28.9784), Cfg.b(c, "hanafi", false))
        return base.mapIndexed { i, x -> x.plusMinutes(Cfg.i(c, "off_$i", 0).toLong()) }
    }

    fun next(c: Context, now: LocalDateTime = LocalDateTime.now()): Nx {
        val d = now.toLocalDate()
        val all = day(c, d.minusDays(1)) + day(c, d) + day(c, d.plusDays(1))
        val ni = all.indexOfFirst { it.isAfter(now) }.coerceAtLeast(1)
        return Nx(ni % 6, all[ni], all[ni - 1])
    }

    /** Kerahat aralıkları: güneş doğuşu, istivâ (öğleden önce), güneş batışı öncesi (yaklaşık) */
    fun kerahat(c: Context, date: LocalDate): List<Pair<LocalDateTime, LocalDateTime>> {
        val t = day(c, date); val dur = Cfg.i(c, "kdur", 45).toLong()
        return listOf(t[1] to t[1].plusMinutes(dur), t[2].minusMinutes(dur) to t[2], t[4].minusMinutes(dur) to t[4])
    }
}

/** Astronomik namaz vakti hesabı (İmsak 18°, Yatsı 17° - Diyanet'e yakın). */
object PrayerCalc {
    private fun r(d: Double) = Math.toRadians(d)
    private fun dg(x: Double) = Math.toDegrees(x)
    private fun fh(a: Double) = ((a % 24) + 24) % 24
    private fun fa(a: Double) = ((a % 360) + 360) % 360

    private fun julian(date: LocalDate): Double {
        var y = date.year; var m = date.monthValue; val d = date.dayOfMonth
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0); val b = 2 - a + floor(a / 4)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** returns (equation of time [h], declination [deg]) */
    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fa(357.529 + 0.98560028 * d)
        val q = fa(280.459 + 0.98564736 * d)
        val l = fa(q + 1.915 * sin(r(g)) + 0.020 * sin(r(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fh(dg(atan2(cos(r(e)) * sin(r(l)), cos(r(l)))) / 15)
        val eqt = fh(q / 15 - ra + 12) - 12
        val decl = dg(asin(sin(r(e)) * sin(r(l))))
        return eqt to decl
    }

    /** İmsak, Güneş, Öğle, İkindi, Akşam, Yatsı */
    fun day(date: LocalDate, lat: Double, lon: Double, hanafi: Boolean): List<LocalDateTime> {
        val tz = ZoneId.systemDefault().rules.getOffset(date.atTime(12, 0)).totalSeconds / 3600.0
        val jd = julian(date) - lon / 360.0
        fun mid(t: Double) = fh(12 - sun(jd + t).first)
        fun ang(a: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t).second
            val n = ((-sin(r(a)) - sin(r(decl)) * sin(r(lat))) / (cos(r(decl)) * cos(r(lat)))).coerceIn(-1.0, 1.0)
            val h = dg(acos(n)) / 15
            return mid(t) + if (ccw) -h else h
        }
        fun asr(t: Double): Double {
            val decl = sun(jd + t).second
            val a = -dg(atan(1.0 / ((if (hanafi) 2 else 1) + tan(r(abs(lat - decl))))))
            return ang(a, t, false)
        }
        var t = listOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0).map { it / 24 }
        repeat(2) {
            t = listOf(
                ang(18.0, t[0], true), ang(0.833, t[1], true), mid(t[2]),
                asr(t[3]), ang(0.833, t[4], false), ang(17.0, t[5], false)
            ).map { it / 24 }
        }
        val h = t.map { it * 24 + tz - lon / 15 }.toMutableList()
        h[2] += 1.0 / 60
        for (i in 1..5) while (h[i] < h[i - 1]) h[i] += 24.0
        return h.map { date.atStartOfDay().plusSeconds((it * 3600).roundToLong()) }
    }

    fun qibla(lat: Double, lon: Double): Float {
        val p1 = r(lat); val p2 = r(21.4225); val dl = r(39.8262 - lon)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return fa(dg(atan2(y, x))).toFloat()
    }
}

