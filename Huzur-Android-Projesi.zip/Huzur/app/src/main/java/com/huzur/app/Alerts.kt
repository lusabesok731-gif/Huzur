package com.huzur.app

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.runBlocking
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.concurrent.thread

private val PI_FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

object Scheduler {
    data class Ev(val ms: Long, val order: Int, val kind: String, val idx: Int)

    private fun ms(t: LocalDateTime) = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    /** Bildirim olayları: P ezan, PRE ön hatırlatma, K kerahat, Z zikir, R yenileme (bildirim/widget) */
    fun events(c: Context, fromMs: Long): List<Ev> {
        val out = ArrayList<Ev>()
        val today = LocalDate.now()
        val pre = Cfg.i(c, "pre", 0)
        val kerOn = Cfg.b(c, "ker", true)
        val dur = Cfg.i(c, "kdur", 45).toLong()
        val zk = Cfg.b(c, "zk", false)
        val pOn = Cfg.b(c, "notif", true)
        for (k in 0..2) {
            val d = today.plusDays(k.toLong())
            val t = PrayerSource.day(c, d)
            for (i in 0..5) {
                out.add(Ev(ms(t[i]), 8, "R", i))
                if (pOn && Cfg.b(c, "pn_$i", i != 1)) {
                    out.add(Ev(ms(t[i]), 1, "P", i))
                    if (pre > 0) out.add(Ev(ms(t[i].minusMinutes(pre.toLong())), 0, "PRE", i))
                }
            }
            if (kerOn) {
                out.add(Ev(ms(t[1]), 2, "K", 0))
                out.add(Ev(ms(t[2].minusMinutes(dur)), 2, "K", 1))
                out.add(Ev(ms(t[4].minusMinutes(dur)), 2, "K", 2))
            }
            out.add(Ev(ms(d.atTime(0, 1)), 9, "R", 9))
            if (zk) {
                val iv = Cfg.i(c, "zkint", 60).coerceAtLeast(5)
                val sh = Cfg.i(c, "zksh", 9); val eh = Cfg.i(c, "zkeh", 22)
                var t0 = d.atTime(sh, 0)
                val end = if (eh > sh) d.atTime(eh, 0) else d.atTime(23, 59)
                while (!t0.isAfter(end)) {
                    out.add(Ev(ms(t0), 3, "Z", ((ms(t0) / 60000L) / iv).toInt()))
                    t0 = t0.plusMinutes(iv.toLong())
                }
            }
        }
        return out.filter { it.ms > fromMs }.sortedWith(compareBy({ it.ms }, { it.order }))
    }

    @SuppressLint("ScheduleExactAlarm")
    fun scheduleNext(c: Context, lastMs: Long, lastOrd: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java), PI_FLAGS))
        val ev = events(c, lastMs - 1).firstOrNull { it.ms > lastMs || (it.ms == lastMs && it.order > lastOrd) } ?: return
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("ms", ev.ms).putExtra("ord", ev.order).putExtra("kind", ev.kind).putExtra("idx", ev.idx)
        val pi = PendingIntent.getBroadcast(c, 1, i, PI_FLAGS)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.ms, pi)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.ms, pi)
    }

    fun rescheduleAll(c: Context) {
        Notifier.persistent(c)
        WidgetUpdater.update(c)
        scheduleNext(c, System.currentTimeMillis(), 99)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val ms = i.getLongExtra("ms", 0L)
        val ord = i.getIntExtra("ord", 0)
        Notifier.fire(c, i.getStringExtra("kind") ?: "R", i.getIntExtra("idx", 0), ms)
        Notifier.persistent(c)
        WidgetUpdater.update(c)
        Scheduler.scheduleNext(c, ms, ord)
        if (Cfg.s(c, "ilceId", "").isNotEmpty() && PrayerSource.daysLeft(c) < 6) {
            val pr = goAsync()
            thread {
                try { if (runBlocking { Loc.refresh(c) }) Scheduler.rescheduleAll(c) } finally { pr.finish() }
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.rescheduleAll(c) }
}

class ReadReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val t = i.getStringExtra("title") ?: return
        Cfg.readDua(c, t)
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(i.getIntExtra("nid", 0))
    }
}

object Sfx {
    private var mp: MediaPlayer? = null
    fun preview(c: Context, res: Int) {
        if (res == 0) return
        try { mp?.release(); mp = MediaPlayer.create(c, res); mp?.start() } catch (e: Exception) {}
    }
}

object Notifier {
    val names = listOf("İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")
    val kerNames = listOf("Güneş doğuşu", "İstivâ (öğle öncesi)", "Güneş batışı öncesi")

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun rawId(c: Context, prefix: String, key: String): Int =
        if (key == "ezan") c.resources.getIdentifier("ezan", "raw", c.packageName)
        else c.resources.getIdentifier(prefix + "_" + key, "raw", c.packageName)

    fun canPost(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

    fun place(c: Context): String {
        val a = Cfg.s(c, "dy_ilce", "")
        return if (a.isEmpty()) Cfg.s(c, "addr", "Konumun") else a + " / " + Cfg.s(c, "dy_il", "")
    }

    private fun channel(c: Context, id: String, name: String, imp: Int, res: Int, vib: Boolean, sound: Boolean) {
        val n = nm(c)
        if (n.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, imp)
        if (sound && res != 0) ch.setSound(
            Uri.parse("android.resource://" + c.packageName + "/" + res),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ) else ch.setSound(null, null)
        ch.enableVibration(vib); ch.setShowBadge(false)
        n.createNotificationChannel(ch)
    }

    private fun open(c: Context, extra: (Intent) -> Unit = {}): PendingIntent {
        val i = Intent(c, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            extra(this)
        }
        return PendingIntent.getActivity(c, (System.nanoTime() % 100000).toInt(), i, PI_FLAGS)
    }

    fun fire(c: Context, kind: String, idx: Int, ms: Long) {
        if (kind == "R" || !canPost(c)) return
        val sound = Cfg.b(c, "sound", true); val vib = Cfg.b(c, "vib", true)
        val at = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ms), ZoneId.systemDefault())
        when (kind) {
            "P", "PRE" -> {
                val key = Cfg.s(c, "ptone", "nur")
                val ch = "p_${key}_${sound}_$vib"
                channel(c, ch, "Ezan vakti bildirimleri", NotificationManager.IMPORTANCE_HIGH, rawId(c, "p", key), vib, sound)
                val title = if (kind == "P") (if (idx == 1) "🌅 Güneş doğdu" else "🕌 ${names[idx]} vakti girdi")
                else "⏳ ${names[idx]} vaktine ${Cfg.i(c, "pre", 0)} dk kaldı"
                val nx = PrayerSource.next(c, at.plusSeconds(5))
                post(c, 100 + idx + (if (kind == "PRE") 10 else 0), ch, title, place(c) + " • " + at.plusMinutes(if (kind == "PRE") Cfg.i(c, "pre", 0).toLong() else 0).format(HM),
                    "Sıradaki vakit: ${names[nx.idx]} ${nx.next.format(HM)}", false, open(c), null)
            }
            "K" -> {
                val key = Cfg.s(c, "ktone", "derin")
                val ch = "k_${key}_${sound}_$vib"
                channel(c, ch, "Kerahat vakti", NotificationManager.IMPORTANCE_HIGH, rawId(c, "k", key), vib, sound)
                val kv = PrayerSource.kerahat(c, at.toLocalDate())[idx]
                post(c, 120 + idx, ch, "⚠️ Kerahat vakti girdi", kerNames[idx] + " • yaklaşık " + kv.second.format(HM) + "'e kadar",
                    "Bu aralıkta nafile namaz kılınmaz. Vakit yaklaşık hesaplanır; Diyanet bilgisini esas al.", false, open(c), null)
            }
            "Z" -> {
                val src = Cfg.s(c, "zksrc", "mix")
                val pool = DUAS.filter { it.ar.length < 220 && when (src) { "hadis" -> it.isHadis; "kuran" -> it.isQuran; else -> it.isHadis || it.isQuran } }
                if (pool.isEmpty()) return
                val d = pool[idx.mod(pool.size)]
                val key = Cfg.s(c, "ztone", "kristal")
                val ch = "z_${key}_${sound}_$vib"
                channel(c, ch, "Zikir hatırlatıcı", NotificationManager.IMPORTANCE_DEFAULT, rawId(c, "z", key), vib, sound)
                val nid = 300 + idx.mod(30)
                val read = PendingIntent.getBroadcast(c, nid, Intent(c, ReadReceiver::class.java).putExtra("title", d.title).putExtra("nid", nid), PI_FLAGS)
                val tap = open(c) { it.putExtra("read", d.title).putExtra("nid", nid) }
                val big = d.ar + "\n\n" + d.ok + "\n\n" + d.tr + "\n📚 " + d.src
                post(c, nid, ch, "📿 " + d.title, d.ar, big, Cfg.b(c, "zkstay", true), tap, read)
            }
        }
    }

    private fun post(c: Context, id: Int, ch: String, title: String, text: String, big: String?, stay: Boolean, tap: PendingIntent, readAction: PendingIntent?) {
        val b = NotificationCompat.Builder(c, ch).setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title).setContentText(text).setContentIntent(tap).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setOngoing(stay)
        if (big != null) b.setStyle(NotificationCompat.BigTextStyle().bigText(big))
        if (readAction != null) b.addAction(0, "✓ Okudum", readAction)
        nm(c).notify(id, b.build())
    }

    /** Bildirim çubuğunda kalıcı: sıradaki vakit + geri sayım */
    fun persistent(c: Context) {
        val n = nm(c)
        if (!Cfg.b(c, "persist", true) || !canPost(c)) { n.cancel(1); return }
        channel(c, "persist", "Kalıcı vakit göstergesi", NotificationManager.IMPORTANCE_LOW, 0, false, false)
        val nx = PrayerSource.next(c)
        val times = PrayerSource.day(c, LocalDate.now())
        val line = times.mapIndexed { i, t -> names[i] + " " + t.format(HM) }.joinToString("   •   ")
        val whenMs = nx.next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val b = NotificationCompat.Builder(c, "persist").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(names[nx.idx] + " • " + nx.next.format(HM))
            .setContentText("Kalan süre · " + place(c))
            .setStyle(NotificationCompat.BigTextStyle().bigText(line))
            .setWhen(whenMs).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(open(c))
        n.notify(1, b.build())
    }
}

object WidgetUpdater {
    fun update(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        val ids = mgr.getAppWidgetIds(ComponentName(c, PrayerWidget::class.java))
        if (ids.isEmpty()) return
        val nx = PrayerSource.next(c)
        val times = PrayerSource.day(c, LocalDate.now())
        val now = LocalDateTime.now()
        val total = Duration.between(nx.prev, nx.next).seconds.coerceAtLeast(1)
        val done = Duration.between(nx.prev, now).seconds.coerceIn(0, total)
        val remainMs = Duration.between(now, nx.next).toMillis().coerceAtLeast(0)
        val rv = RemoteViews(c.packageName, R.layout.widget_prayer)
        rv.setTextViewText(R.id.w_city, "📍 " + Notifier.place(c))
        rv.setTextViewText(R.id.w_next, Notifier.names[nx.idx] + " · " + nx.next.format(HM))
        rv.setChronometer(R.id.w_chrono, SystemClock.elapsedRealtime() + remainMs, null, true)
        rv.setChronometerCountDown(R.id.w_chrono, true)
        rv.setProgressBar(R.id.w_prog, 1000, (done * 1000 / total).toInt(), false)
        val cells = intArrayOf(R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5)
        for (i in 0..5) rv.setTextViewText(cells[i], Notifier.names[i] + "\n" + times[i].format(HM))
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 7, Intent(c, MainActivity::class.java), PI_FLAGS))
        mgr.updateAppWidget(ids, rv)
    }
}

class PrayerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { WidgetUpdater.update(c); Scheduler.rescheduleAll(c) }
    override fun onEnabled(c: Context) { Scheduler.rescheduleAll(c) }
}
