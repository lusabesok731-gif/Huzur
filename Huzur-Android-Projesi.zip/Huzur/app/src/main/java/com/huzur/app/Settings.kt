@file:OptIn(ExperimentalLayoutApi::class)

package com.huzur.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

private val PTONES = listOf("nur" to "Nûr", "su" to "Su Damlası", "tesbih" to "Tesbih", "seher" to "Seher", "sukun" to "Sükûn", "hilal" to "Hilâl")
private val KTONES = listOf("derin" to "Derin", "damla" to "Damla", "boncuk" to "Boncuk")
private val ZTONES = listOf("kristal" to "Kristal", "dam" to "Damla", "boncuk" to "Boncuk")

@Composable
fun Group(emoji: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    SectionTitle(emoji, title)
    Panel(content = content)
}

@Composable
fun Label(s: String) { T(s, 12, LocalPal.current.sub, FontWeight.Medium, Modifier.padding(top = 8.dp, bottom = 6.dp)) }

@Composable
fun ToneRow(opts: List<Pair<String, String>>, sel: String, prefix: String, st: Store, key: String) {
    val ctx = LocalContext.current
    val all = if (prefix == "p" && Notifier.rawId(ctx, "p", "ezan") != 0) opts + ("ezan" to "Ezan (ezan.mp3)") else opts
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        all.forEach { (k, n) -> Chip("🔊 $n", sel == k) { st.put(key, k); Sfx.preview(ctx, Notifier.rawId(ctx, prefix, k)) } }
    }
}

@Composable
fun SettingsScreen(st: Store) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picker by remember { mutableStateOf(false) }
    var showOff by remember { mutableStateOf(false) }
    val locL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { scope.launch { st.locate() } }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { st.reload() }
    val bat = batteryExempt(ctx)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("Ayarlar", 26, p.text, FontWeight.SemiBold)

        Group("📍", "Konum ve vakitler") {
            T(st.s("addr", "Henüz konum alınmadı"), 14, p.text, FontWeight.Medium, lh = 20)
            T("Diyanet ilçesi: ${st.s("dy_ilce", "—")} / ${st.s("dy_il", "—")}", 12, p.accent, modifier = Modifier.padding(top = 2.dp))
            if (st.locStatus.isNotEmpty()) T(st.locStatus, 12, p.sub, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton(if (st.locBusy) "Aranıyor…" else "📍 Konumumu bul", Modifier.weight(1f)) {
                    if (!st.locBusy) locL.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
                PButton("İl / İlçe seç", Modifier.weight(1f), filled = false) { picker = true }
            }
            Spacer(Modifier.height(8.dp))
            PButton("🔄 Diyanet vakitlerini yenile", Modifier.fillMaxWidth(), filled = false) { scope.launch { st.refreshTimes() } }
            SwitchRow("İkindi: Hanefî (yedek hesap)", "Yalnızca Diyanet verisi yokken kullanılan hesabı etkiler", st.b("hanafi", false)) { st.put("hanafi", it) }
            Box(Modifier.pressable { showOff = !showOff }.padding(vertical = 6.dp)) { T(if (showOff) "▾ Vakit düzeltme (dakika)" else "▸ Vakit düzeltme (dakika)", 13, p.accent, FontWeight.Medium) }
            if (showOff) Notifier.names.forEachIndexed { i, n -> Stepper(n, st.i("off_$i", 0), "dk", -30, 30) { st.put("off_$i", it) } }
        }

        Group("🔔", "Ezan bildirimleri") {
            SwitchRow("Vakit bildirimleri", "Ezan vaktinde bildirim ve ses", st.b("notif", true)) { st.put("notif", it) }
            Label("Hangi vakitlerde bildirim gelsin?")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Notifier.names.forEachIndexed { i, n -> val on = st.b("pn_$i", i != 1); Chip(n, on) { st.put("pn_$i", !on) } }
            }
            Label("Vakitten önce hatırlat")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 5, 10, 15, 30, 45).forEach { m -> Chip(if (m == 0) "Kapalı" else "$m dk", st.i("pre", 0) == m) { st.put("pre", m) } }
            }
            Label("Ezan bildirim sesi (kısa)")
            ToneRow(PTONES, st.s("ptone", "nur"), "p", st, "ptone")
            Text0("Kendi ezan kaydını res/raw/ezan.mp3 olarak eklersen burada seçilebilir.")
            SwitchRow("Kalıcı vakit bildirimi", "Bildirim çubuğunda sıradaki vakit ve geri sayım hep görünsün", st.b("persist", true)) { st.put("persist", it) }
            if (Build.VERSION.SDK_INT >= 33 && !Notifier.canPost(ctx)) PButton("Bildirim iznini ver", Modifier.fillMaxWidth()) { notifL.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }

        Group("⚠️", "Kerahat vakitleri") {
            SwitchRow("Kerahat bildirimi", "Güneş doğuşu, istivâ ve güneş batışı öncesi", st.b("ker", true)) { st.put("ker", it) }
            Stepper("Kerahat süresi", st.i("kdur", 45), "dk", 30, 60, 5) { st.put("kdur", it) }
            Label("Kerahat bildirim sesi")
            ToneRow(KTONES, st.s("ktone", "derin"), "k", st, "ktone")
            Text0("Kerahat süreleri yaklaşık hesaplanır; Diyanet bilgisini esas al.")
        }

        Group("📿", "Zikir hatırlatıcı") {
            SwitchRow("Zikir hatırlat", "Seçtiğin aralıklarla hadis ve ayetlerden zikir gelir", st.b("zk", false)) { st.put("zk", it) }
            Label("Sıklık")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15 to "15 dk", 30 to "30 dk", 60 to "1 saat", 120 to "2 saat", 180 to "3 saat", 240 to "4 saat").forEach { (m, n) -> Chip(n, st.i("zkint", 60) == m) { st.put("zkint", m) } }
            }
            Stepper("Özel aralık", st.i("zkint", 60), "dk", 5, 720, 5) { st.put("zkint", it) }
            Stepper("Başlangıç saati", st.i("zksh", 9), ":00", 0, 23) { st.put("zksh", it) }
            Stepper("Bitiş saati", st.i("zkeh", 22), ":00", 0, 23) { st.put("zkeh", it) }
            Label("İçerik")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("mix" to "Karışık", "hadis" to "Hadis", "kuran" to "Kur'an").forEach { (k, n) -> Chip(n, st.s("zksrc", "mix") == k) { st.put("zksrc", k) } }
            }
            Label("Zikir bildirim sesi")
            ToneRow(ZTONES, st.s("ztone", "kristal"), "z", st, "ztone")
            SwitchRow("Dokunana kadar kalsın", "Bildirim sen dokunup “okudum” diyene kadar silinmez", st.b("zkstay", true)) { st.put("zkstay", it) }
        }

        Group("🎨", "Görünüm") {
            Label("Tema")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Otomatik", "light" to "Aydınlık", "dark" to "Karanlık").forEach { (k, n) -> Chip(n, st.s("theme", "auto") == k) { st.put("theme", k) } }
            }
            Label("Vurgu rengi (yeşil tonları)")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ACCENTS.forEach { a ->
                    val on = st.s("accent", "zumrut") == a.key
                    Box(
                        Modifier.size(38.dp).pressable { st.put("accent", a.key) }.clip(CircleShape).background(if (p.dark) a.dk else a.lt)
                            .border(if (on) 3.dp else 1.dp, if (on) p.text else p.line, CircleShape)
                    )
                }
            }
            Label("Arapça yazı boyutu")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(22 to "Küçük", 26 to "Orta", 30 to "Büyük", 34 to "Çok büyük").forEach { (s, n) -> Chip(n, st.i("arsz", 26) == s) { st.put("arsz", s) } }
            }
            SwitchRow("Okunuşu göster", "Duaların Türkçe okunuşu", st.b("showok", true)) { st.put("showok", it) }
            SwitchRow("Anlamı göster", "Duaların Türkçe anlamı", st.b("showtr", true)) { st.put("showtr", it) }
        }

        Group("🔊", "Ses ve titreşim") {
            SwitchRow("Ses", "Bildirim ve tesbihat sesleri", st.b("sound", true)) { st.put("sound", it) }
            SwitchRow("Titreşim", "Bildirim titreşimi", st.b("vib", true)) { st.put("vib", it) }
            SwitchRow("Dokunma titreşimi", "Tesbihat sayarken hafif titreşim", st.b("haptic", true)) { st.put("haptic", it) }
        }

        Group("🛠️", "Sistem ve güvenilirlik") {
            T(if (bat) "✓ Pil kısıtlaması kaldırılmış" else "⚠️ Pil kısıtlaması açık: bildirimler gecikebilir", 13, if (bat) p.accent else p.gold, FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            if (!bat) PButton("🔋 Pil kısıtlamasını kaldır", Modifier.fillMaxWidth()) { openBattery(ctx) }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("⏰ Alarm izni", Modifier.weight(1f), filled = false) {
                    if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                }
                PButton("Uygulama ayarları", Modifier.weight(1f), filled = false) { openAppDetails(ctx) }
            }
            Label("Test bildirimleri")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("🕌 Ezan", Modifier.weight(1f), filled = false) { Notifier.fire(ctx, "P", 2, System.currentTimeMillis()) }
                PButton("⚠️ Kerahat", Modifier.weight(1f), filled = false) { Notifier.fire(ctx, "K", 1, System.currentTimeMillis()) }
                PButton("📿 Zikir", Modifier.weight(1f), filled = false) { Notifier.fire(ctx, "Z", (System.currentTimeMillis() / 60000L).toInt(), System.currentTimeMillis()) }
            }
            Text0("Widget eklemek için ana ekranda boşluğa uzun bas › Widget'lar › Huzur.")
        }
        Spacer(Modifier.height(10.dp))
    }
    if (picker) PickerDialog(st) { picker = false }
}

@Composable
fun Text0(s: String) { T(s, 11, LocalPal.current.sub, lh = 16, modifier = Modifier.padding(top = 6.dp)) }

@Composable
fun PickerDialog(st: Store, onClose: () -> Unit) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var cities by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var dists by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var sel by remember { mutableStateOf<Pair<String, String>?>(null) }
    var q by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { try { cities = Loc.cities() } catch (e: Exception) { err = "Liste alınamadı. İnternet bağlantını kontrol et." } }
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onClose) {
        Column(Modifier.clip(shape).background(p.bg2).border(1.dp, p.line, shape).padding(18.dp)) {
            val s = sel
            T(if (s == null) "İl seç" else pretty(s.second) + " · İlçe seç", 18, p.text, FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.card).padding(horizontal = 14.dp, vertical = 11.dp)) {
                BasicTextField(
                    q, { q = it }, singleLine = true, cursorBrush = SolidColor(p.accent),
                    textStyle = TextStyle(color = p.text, fontSize = 14.sp, fontFamily = Sans),
                    decorationBox = { inner -> if (q.isEmpty()) T("Ara…", 14, p.sub); inner() }
                )
            }
            if (err.isNotEmpty()) T(err, 12, p.gold, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(8.dp))
            val base = if (s == null) cities else dists
            val n = Loc.norm(q)
            val list = if (n.isEmpty()) base else base.filter { Loc.norm(it.second).contains(n) }
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(list) { item ->
                    Box(Modifier.fillMaxWidth().clickable {
                        if (s == null) {
                            sel = item; q = ""
                            scope.launch { try { dists = Loc.districts(item.first) } catch (e: Exception) { err = "İlçeler alınamadı." } }
                        } else {
                            st.chooseDistrict(s.second, item.first, item.second)
                            scope.launch { st.refreshTimes() }
                            onClose()
                        }
                    }.padding(vertical = 12.dp, horizontal = 6.dp)) { T(pretty(item.second), 15, p.text) }
                }
            }
        }
    }
}
