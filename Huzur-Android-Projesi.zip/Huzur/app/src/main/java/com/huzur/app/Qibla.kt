package com.huzur.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun QiblaScreen(st: Store) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var az by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }
    val q = PrayerCalc.qibla(Cfg.d(ctx, "lat", 41.0082), Cfg.d(ctx, "lon", 28.9784))
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s == null) hasSensor = false
        val l = object : SensorEventListener {
            val rm = FloatArray(9); val o = FloatArray(3)
            override fun onSensorChanged(e: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rm, e.values)
                SensorManager.getOrientation(rm, o)
                val a = ((Math.toDegrees(o[0].toDouble()) + 360) % 360).toFloat()
                var d = a - az
                while (d > 180) d -= 360
                while (d < -180) d += 360
                az = (az + d * 0.15f + 360f) % 360f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    val diff = abs(((q - az + 540f) % 360f) - 180f)
    val aligned = diff < 4f
    val glow by animateFloatAsState(if (aligned) 1f else 0f, tween(400), label = "qg")
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        T("Kıble", 26, p.text, FontWeight.SemiBold, Modifier.fillMaxWidth())
        T(Notifier.place(ctx) + " • Kâbe yönü ${q.toInt()}°", 12, p.sub, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(320.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val rad = size.minDimension / 2
                drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = 0.10f + 0.22f * glow), p.card), center, rad), rad)
                drawCircle(lerp(p.line, p.accent, glow), rad, style = Stroke(3.dp.toPx()))
                rotate(-az) {
                    for (i in 0 until 72) {
                        val len = if (i % 9 == 0) 16.dp.toPx() else 7.dp.toPx()
                        val a = i * 5.0 * PI / 180
                        val r = rad - 8.dp.toPx()
                        drawLine(
                            p.sub.copy(alpha = 0.6f),
                            center + Offset((sin(a) * r).toFloat(), (-cos(a) * r).toFloat()),
                            center + Offset((sin(a) * (r - len)).toFloat(), (-cos(a) * (r - len)).toFloat()),
                            2.dp.toPx()
                        )
                    }
                }
                val tri = Path().apply {
                    moveTo(center.x, 4.dp.toPx()); lineTo(center.x - 10.dp.toPx(), 28.dp.toPx()); lineTo(center.x + 10.dp.toPx(), 28.dp.toPx()); close()
                }
                drawPath(tri, p.accent)
            }
            Box(Modifier.fillMaxSize().rotate(-az), contentAlignment = Alignment.TopCenter) {
                Text("K", color = Color(0xFFF87171), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = Sans, modifier = Modifier.padding(top = 38.dp))
            }
            Box(Modifier.fillMaxSize().rotate(q - az), contentAlignment = Alignment.TopCenter) {
                Text("🕋", fontSize = 34.sp, modifier = Modifier.padding(top = 58.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        T(
            if (!hasSensor) "Bu cihazda pusula sensörü yok" else if (aligned) "✓ Kıble yönündesin" else "Telefonu düz tut, 🕋 işaretini üstteki oka getir",
            15, if (aligned) p.accent else p.sub, FontWeight.Medium, align = TextAlign.Center
        )
        T("Doğruluk için telefonu havada 8 çizer gibi hareket ettir.", 12, p.sub, modifier = Modifier.padding(top = 6.dp), align = TextAlign.Center)
    }
}
