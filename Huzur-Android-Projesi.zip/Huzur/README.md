# Huzur – Ezan Vakti, Tesbihat ve Dualar

## APK alma
**A) Android Studio:** Klasörü aç → Gradle sync → Build > Build APK(s) → app/build/outputs/apk/debug/app-debug.apk
**B) GitHub Actions:** Projeyi GitHub'a yükle → Actions › "APK Derle" › Run workflow → Artifacts › Huzur-APK.

## Veri kaynağı
Vakitler Diyanet İşleri Başkanlığı verisinden (ezanvakti.emushaf.net) ilçe bazında çekilir ve cihazda saklanır.
Konum → OpenStreetMap (mahalle/sokak) → Diyanet ilçesi eşleşmesi yapılır. Veri yoksa astronomik hesap kullanılır.

## Ezan sesi
Lisanslı ezan kaydını app/src/main/res/raw/ezan.mp3 olarak ekle; Ayarlar'da seçilebilir.
